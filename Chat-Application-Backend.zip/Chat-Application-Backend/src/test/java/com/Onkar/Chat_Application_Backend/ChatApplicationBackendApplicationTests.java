package com.Onkar.Chat_Application_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatApplicationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
